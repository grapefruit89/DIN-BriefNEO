# DIN-BriefNEO (historical snapshot)

**Origin:** This is a full snapshot of a previous complete version of the DIN-BriefNEO project (circa April 2026), including the full old codebase, issues, old agent configurations, and build artifacts.

**Archived on:** 2026-06 during the major archive cleanup.

**Reason for archiving:** This represents an older state of the entire project before the major refactoring, introduction of the current longevity covenant, layered antipattern system, Reconciliation/Fitness Score, and the move to the clean ktueller_arbeitsordner/ structure. The current active work is a clean, refactored continuation.

**Potentially still useful for reference:**
- Historical context on previous feature implementations (e.g., old address autocomplete, salutation engine, etc.).
- Examples of earlier architecture decisions and code that was later improved or replaced.
- Old issues and specs that document the project's evolution.
- Reference for what was tried and why certain approaches were abandoned (useful for the Testballon learning process).

Contains internal old folders like .brain, .gemini, .specify, .git from that era — these are part of the historical snapshot.

This is a static historical snapshot. Do not modify the contents for active development.
